
package application.form.other;
import application.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import raven.toast.Notifications;
/**
 *
 * @author Dexter
 */
public class StudentFormDatabase 
{
    static int save(String Student, String Birth, String Gender, int MobileNO, String StudentID, String Address, String City, String Dist, String Branch, String Email) throws Exception
    {
         try{
            Connection con=DatabaseConnection.getConnection();
            PreparedStatement ps=con.prepareStatement("insert into StudentForm(Student,Birth,Gender,MobileNO,StudentID,Address,City,Dist,Branch,Email) values(?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, Student);
            ps.setString(2, Birth);
            ps.setString(3,Gender);
            ps.setInt(4, MobileNO);
            ps.setString(5, StudentID);
            ps.setString(6, Address);
            ps.setString(7, City);
            ps.setString(8, Dist);
            ps.setString(9, Branch);
            ps.setString(10, Email);
            int status  = ps.executeUpdate();
            con.close();
            return status;
        }
        catch(Exception e)
        {
            System.out.println(e);
            Notifications.getInstance().show(Notifications.Type.INFO, Notifications.Location.TOP_CENTER, "Data is Not save in Database");

        }
        return 0;
    }

//    static int save(String Student, String Birth, String Gender, String MobileNO, String StudentID, String Address, String City, String Dist, String Branch, String Email) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
}
