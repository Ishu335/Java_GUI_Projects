/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package application.form.other;
import application.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import raven.toast.Notifications;
/**
 *
 * @author Dexter
 */
public class AddBookDatabase 
{

    /**
     *
     * @param bookname
     * @param authorname
     * @param totalcount
     * @param bookcellno
     * @param booksection
     */
    public static int save(String bookname,String authorname,int totalcount,int bookcellno,String booksection, String branch ) throws Exception
    {
        try{
            Connection con=DatabaseConnection.getConnection();
            PreparedStatement ps=con.prepareStatement("insert into books(bookname,authorname,totalcount,bookcellno,booksection,branch) values(?,?,?,?,?,?)");
            ps.setString(1, bookname);
            ps.setString(2, authorname);
            ps.setInt(3,totalcount);
            ps.setInt(4, bookcellno);
            ps.setString(5, booksection);
            ps.setString(6, branch);
            int status  = ps.executeUpdate();
            con.close();
            return status;
        }
        catch(Exception e)
        {
            System.out.println(e);
            Notifications.getInstance().show(Notifications.Type.INFO, Notifications.Location.TOP_CENTER, "Data is Not save in Database");

        }
        return 0;
    }
}
    

