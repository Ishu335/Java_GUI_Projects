package application;


import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
	public static Connection getConnection()
//    public static void main(String args[])
    {
		Connection con=null;
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demotest","root","mysql");
			if (con==null)
			{
				System.out.println("TRY");
				
			}
			else
			{
				System.out.println("Done");
			}
		}catch(Exception e){System.out.println(e);}
		return con;
	}

}

